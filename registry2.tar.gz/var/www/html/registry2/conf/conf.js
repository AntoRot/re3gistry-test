"use strict";

/// *** App configuration file ***///

var registryApp = {};

// The default language of the app (used as a fallback if the language is not
// passed by URL or cannot be retrieved by Browser language)
//registryApp.defaultLanguage = 'en';
registryApp.defaultLanguage = 'it';

// Search maximum results per page
registryApp.maxSearchResultsPerPage = 10;

// Force http URIs (even if the original call has https URIs)
registryApp.forceHttpURIs = true;

// The app's base URLs
//registryApp.hostURL = '//10.14.251.252/registry';
//registryApp.searchURL = '//10.14.251.252/registry/search';
registryApp.hostURL = '//registry.geodati.gov.it/registry';
registryApp.searchURL = '//registry.geodati.gov.it/registry/search';
//registryApp.searchApiURL = '//10.14.251.252/registry/searchapi';
//registryApp.dataServiceURL = '//10.14.251.252/registry/rest';
registryApp.searchApiURL = '//registry.geodati.gov.it/registry/searchapi';
registryApp.dataServiceURL = '//registry.geodati.gov.it/registry/rest';
